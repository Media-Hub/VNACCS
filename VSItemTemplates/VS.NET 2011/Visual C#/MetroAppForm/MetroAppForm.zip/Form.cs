using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace $rootnamespace$
{
    public partial class $safeitemrootname$ : DevComponents.DotNetBar.Metro.MetroAppForm
    {
        public $safeitemrootname$()
        {
            InitializeComponent();
        }
    }
}