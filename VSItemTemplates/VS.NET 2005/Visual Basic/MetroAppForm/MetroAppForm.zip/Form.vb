Public Class $safeitemrootname$

End Class
